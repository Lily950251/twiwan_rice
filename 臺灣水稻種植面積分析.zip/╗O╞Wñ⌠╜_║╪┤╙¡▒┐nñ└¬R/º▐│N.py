import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import pandas as pd
import numpy as np
import sqlite3
plt.rc('font', family='Microsoft JhengHei')
plt.rc('axes', unicode_minus = False)
#%%資料載入
year = []
rice_area = []
rice_yield = []
rice_yield_per_area = []
conn = sqlite3.connect(r'資料庫\project.sqlite')
sql_str = '''SELECT "年份","稻米種植面積(公頃)","糙米產量(公噸)","單位面積產量(公噸/公頃)"\
FROM "水稻生產資料"'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])
    rice_yield.append(row[2])
    rice_yield_per_area.append(row[3])
conn.close()

year = pd.Series(year)
rice_area = pd.Series(rice_area)
rice_yield = pd.Series(rice_yield)
rice_yield_per_area = pd.Series(rice_yield_per_area)
#%%水稻產量_面積
fig, ax1 = plt.subplots()
plt.xlabel("年份 (民國)",size=16)
plt.xlim(42,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, rice_area,
                color = "green",
                alpha = 0.4,
                label = "水稻種植面積 ")
ax1.set_ylabel("水稻種植面積 (公頃)", color = "green", size = 16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot2, = ax2.plot(year,rice_yield,
                  color = "black",
                  linewidth = 3,
                  label = "稻米產量")
ax2.set_ylabel("稻米產量 (公噸)", size = 16, color = "black")
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')
ax2.set_yticks(np.array([0,500000,1000000,1500000,2000000,2500000])) #將刻度拉成相等的間距 (原本的間距很怪)
ax2.yaxis.set_major_formatter(formatter)
plt.legend(handles = [plot1, plot2],
           bbox_to_anchor = (1,1),  
           loc = "lower right",  #圖例右下對齊(1,1)
           ncol = 2)
plt.savefig("area_yield.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)

#%%加上單位面積產量
fig, ax1 = plt.subplots()
plt.xlabel("年份 (民國)",size=16)
plt.xlim(42,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
ax3 = ax1.twinx()
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, rice_area,
                color = "green",
                alpha = 0.4,
                label = "水稻種植面積")
ax1.set_ylabel("水稻種植面積 (公頃)",color="green",size=16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot2, = ax2.plot(year, rice_yield,
                  color = "black",
                  linewidth = 3,
                  label = "稻米產量")
ax2.set_ylabel("稻米產量 (公噸)",size=16,color="black")
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')
ax2.set_yticks(np.array([0,500000,1000000,1500000,2000000,2500000])) #將刻度拉成相等的間距 (原本的間距很怪)
ax2.yaxis.set_major_formatter(formatter)

plot3, = ax3.plot(year, rice_yield_per_area,
                  "--",
                  color = "red",
                  linewidth = 3,
                  label = "單位面積產量 (公噸/公頃)")
ax3.axis("off")  # 關閉 y 軸
# subx = [50,60,70,80,90,100,110]  #添加文字，但是太亂了
# for i,j in zip(year,rice_yield_per_area):
#     if i in subx:
#         ax3.text(i-0.2,j+0.25,j,size=12,color="red")

plt.legend(handles = [plot1, plot2, plot3],
           bbox_to_anchor = (1,1),  
           loc = "lower right",  #圖例右下對齊(1,1)
           ncol = 3)  
plt.savefig("rice_yield_per_area",
            transparent = True,
            bbox_inches = "tight",
            dpi = 300)

#%%皮爾森相關性
data = pd.DataFrame({"rice_area":rice_area,"rice_yield":rice_yield,"rice_yield_per_area":rice_yield_per_area})
cor = data.corr()

plt.figure()
sns.heatmap(cor,
            vmin = -1,
            vmax = 1,
            annot=True)
plt.savefig("yield_ricearea_cor.png",
            transparent=True,
            bbox_inches='tight',
            pad_inches=0.5,dpi=300)
 


 

