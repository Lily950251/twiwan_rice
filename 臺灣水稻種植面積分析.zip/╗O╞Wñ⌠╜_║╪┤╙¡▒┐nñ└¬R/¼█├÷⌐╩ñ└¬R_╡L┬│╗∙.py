import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import sqlite3
plt.rc('font', family='Microsoft JhengHei')
plt.rc('axes', unicode_minus = False)
#%%
year = []
rice_area = []
rice_yield_per_area = []
farmer = []
trans_money = []  #轉作雜糧
fallow_money = [] #休耕
people = []
rice_per_person = []
rice_price = []
total_index = [0]*28

conn = sqlite3.connect(r'資料庫\project.sqlite')
sql_str = '''SELECT "年份","稻米種植面積(公頃)","單位面積產量(公噸/公頃)"\
FROM "水稻生產資料"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])
    rice_yield_per_area.append(row[2])

sql_str = '''SELECT "總人口數 (萬人)","農業就業人口 (%)"\
FROM "農業勞動力"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    people.append(row[0])
    farmer.append(row[1])

sql_str = '''SELECT "最高轉作雜糧", "休耕補貼(綠肥)"\
FROM "政策補貼"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    trans_money.append(row[0])
    fallow_money.append(row[1])
    
sql_str = '''SELECT "米"\
FROM "每人每年純糧食供給量"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    rice_per_person.append(row[0])

    
sql_str = '''SELECT "總指數"\
FROM "消費者物價基本分類暨項目群指數"\
WHERE "年份" BETWEEN 70 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    total_index.append(row[0])

conn.close()

year = pd.Series(year)-110  #110年作為基期年
rice_area = pd.Series(rice_area)
people = pd.Series(people)
rice_per_person = pd.Series(rice_per_person)
rice_yield_per_area = pd.Series(rice_yield_per_area)
farmer = pd.Series(farmer)
total_index = pd.Series(total_index)
#%%資料處裡
#補貼標準化
std_trans_money = trans_money*(100/total_index)  
std_fallow_money = fallow_money*(100/total_index)
    #total_index沒有70年以前的資料，計算後std_trans_money、std_fallow_money前面會變成nan-->補0 
std_trans_money = pd.Series(std_trans_money)
std_fallow_money = pd.Series(std_fallow_money)
std_trans_money = std_trans_money.fillna(0)
std_fallow_money = std_fallow_money.fillna(0)
#需求量
need = people*rice_per_person*10000  #需求量：人口數 (萬人)*人均糧食供應量(米)
#%%相關性分析
data = pd.DataFrame({"水稻種植面積":rice_area, "需求量":need, "農民占比":farmer,
                     "標準化休耕補貼金額":std_fallow_money, "標準化轉作補貼金額":std_trans_money,
                     "單位面積產量":rice_yield_per_area})
cor = data.corr()
plt.figure()
sns.heatmap(cor,
            vmin = -1,
            vmax = 1,
            annot = True)
plt.savefig("cor_no_riceprice_new.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)

