import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import pandas as pd
import numpy as np
import sqlite3
plt.rc('font', family='Microsoft JhengHei')
plt.rc('axes', unicode_minus = False)
#%%資料載入
year = []
rice_area = []
people = []
rice_per_person = []
wheat_per_person = []
conn = sqlite3.connect(r'資料庫\project.sqlite')

sql_str = '''SELECT "年份","稻米種植面積(公頃)"\
FROM "水稻生產資料"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])

sql_str = '''SELECT "總人口數 (萬人)"\
FROM "農業勞動力"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    people.append(row[0])

sql_str = '''SELECT "米","小麥"\
FROM "每人每年純糧食供給量"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    rice_per_person.append(row[0])
    wheat_per_person.append(row[1])

conn.close()

year = pd.Series(year)
rice_area = pd.Series(rice_area)
people = pd.Series(people)
rice_per_person = pd.Series(rice_per_person)
wheat_per_person = pd.Series(wheat_per_person)
#%%人口_水稻種植面積 繪圖
fig, ax1 = plt.subplots()
plt.xlabel("年份 (民國)",size = 16)
plt.xlim(42,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, rice_area,
                color = "green",
                alpha = 0.4,
                label = "水稻種植面積")
ax1.set_ylabel("水稻種植面積 (公頃)", color = "green", size = 16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot2, = ax2.plot(year,people,
                  color = "black",
                  linewidth = 3,
                  label = "人口數")
ax2.set_ylabel("人口數 (萬人)", size = 16, color = "black")
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')
ax2.set_ylim(0,2500)
ax2.set_yticks(np.array([0,500,1000,1500,2000,2500])) #將刻度拉成相等的間距 (原本的間距很怪)
ax2.yaxis.set_major_formatter(formatter)

plt.legend(handles = [plot1, plot2],
           bbox_to_anchor = (1,1),  
           loc = "lower right",  #圖例的何處和錨點對齊
           ncol = 2)

plt.savefig("area_people.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)

#%%每人每年純糧食供給量_水稻種植面積 繪圖
fig, ax = plt.subplots()
plt.xlabel("年份 (民國)", size=16)
plt.ylabel("糧食供給量 (公斤/人)", color = "black",size = 16)
plt.xlim(42,112)

plot1, = ax.plot(year, rice_per_person,
                 color = "green",
                 linewidth = 3,
                 label = "米")

plot2, = ax.plot(year, wheat_per_person,
                 color = "black",
                 linewidth = 3,
                 label = "小麥")

plt.legend(handles = [plot1, plot2],
           bbox_to_anchor = (1,1),
           loc = "lower right",
           ncol = 2) 

plt.savefig("Supply",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)
#%%皮爾森相關性
need = people*rice_per_person  #需求量：人口數*人均糧食供應量(米)
data = pd.DataFrame({"rice_area":rice_area,"need":need})
cor = data.corr()

plt.figure()
sns.heatmap(cor,
            vmin = -1,
            vmax = 1,
            annot=True)
plt.savefig("need_ricearea_cor.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)
 

