import numpy as np
import pandas as pd
import sqlite3
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split as tts
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
#%%
year = []
rice_area = []
rice_yield_per_area = []
farmer = []
trans_money = []  #轉作雜糧
fallow_money = [] #休耕
people = []
rice_per_person = []
rice_price = []
total_index = [0]*28  #前面28年沒有資料-->補0

conn = sqlite3.connect(r'資料庫\project.sqlite')
sql_str = '''SELECT "年份","稻米種植面積(公頃)","單位面積產量(公噸/公頃)"\
FROM "水稻生產資料"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])
    rice_yield_per_area.append(row[2])

sql_str = '''SELECT "總人口數 (萬人)","農業就業人口 (%)"\
FROM "農業勞動力"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    people.append(row[0])
    farmer.append(row[1])

sql_str = '''SELECT "最高轉作雜糧", "休耕補貼(綠肥)"\
FROM "政策補貼"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    trans_money.append(row[0])
    fallow_money.append(row[1])
    
sql_str = '''SELECT "米"\
FROM "每人每年純糧食供給量"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    rice_per_person.append(row[0])


sql_str = '''SELECT "總指數"\
FROM "消費者物價基本分類暨項目群指數"\
WHERE "年份" BETWEEN 70 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    total_index.append(row[0])

conn.close()

year = pd.Series(year)-110  #110年作為基期年
rice_area = pd.Series(rice_area)
people = pd.Series(people)
rice_per_person = pd.Series(rice_per_person)
rice_yield_per_area = pd.Series(rice_yield_per_area)
farmer = pd.Series(farmer)
total_index = pd.Series(total_index)
#%%資料處裡
#補貼標準化
std_trans_money = trans_money*(100/total_index)  
std_fallow_money = fallow_money*(100/total_index)
    #前面會變成nan 
std_trans_money = pd.Series(std_trans_money)
std_fallow_money = pd.Series(std_fallow_money)
std_trans_money = std_trans_money.fillna(0)
std_fallow_money = std_fallow_money.fillna(0)
#需求量
need = people*rice_per_person*10000  #需求量：人口數*人均糧食供應量(米)
#%%建模
X = pd.DataFrame({"farmer":farmer,
                  "need":need,
                  #"std_trans_money":std_trans_money,
                  "std_fallow_money":std_fallow_money,
                  "rice_yield_per_area":rice_yield_per_area})
y = rice_area
std = StandardScaler()
std_model = std.fit(X)  #X標準化
std_X = std_model.transform(X)
xTrain, xTest, yTrain, yTest = tts(std_X, y, test_size=0.2, random_state=10)
lm = LinearRegression()
lm.fit(xTrain,yTrain)
pre_train = lm.predict(xTrain)
mse_train = np.mean((yTrain-pre_train)**2)
pre_test = lm.predict(xTest)
mse_test = np.mean((yTest-pre_test)**2)
print('MSE_train=',mse_train)
print('R-squared_train=',lm.score(xTrain, yTrain))  
print('MSE_test=',mse_test)
print('R-squared_test=',lm.score(xTest, yTest)) 
#%%模型迴歸係數分析  -->發現轉作補貼沒有顯著性，去掉之後重跑
std_X_ = sm.add_constant(std_X)  #增加截距項
xTrain_, xTest_, yTrain_, yTest_ = tts(std_X_, y, test_size=0.2, random_state=10)
model = sm.OLS(yTrain_, xTrain_).fit()
print(model.summary())
#%%未來物價指數預測
X_index = pd.DataFrame({"year":year[28:]})  #民國70年 -->索引是28
y_index = total_index[28:]
xTrain_index, xTest_index, yTrain_index, yTest_index = tts(X_index, y_index, test_size=0.2, random_state=10)
lm_index = LinearRegression()
lm_index.fit(xTrain_index, yTrain_index)
pre_train_index = lm_index.predict(xTrain_index)
mse_train_index = np.mean((yTrain_index-pre_train_index)**2)
pre_test_index = lm_index.predict(xTest_index)
mse_test_index = np.mean((yTest_index-pre_test_index)**2)
print('Index_MSE_train=',mse_train_index)
print('Index_R-squared_train=',lm_index.score(xTrain_index, yTrain_index))  #0.97  
print('Index_MSE_test=',mse_test_index)
print('Index_R-squared_test=',lm_index.score(xTest_index, yTest_index)) #0.94
#%%
state = "Y"
print("水稻種植面積預測")
while state.upper() == "Y":
    pre_year = eval(input("請輸入想要預測的年份 (民國)："))
    pre_farmer = eval(input("請輸入假設的農民佔比 (%)："))
    pre_population = eval(input("請輸入假設的全國人口數 (萬人)："))
    pre_supply = eval(input("請輸入假設的每人每年食米量 (kg)："))
    pre_fallow_money = eval(input("請輸入假設的休耕補貼金額："))
    #預測物價指數
    if pre_year > 112 or pre_year < 70:
        pre_X_index = pd.DataFrame({"year":[pre_year-110]})
        pre_total_index = lm_index.predict(pre_X_index)
    else:  #有資料的區間 70~112年
        pre_total_index = total_index[pre_year-42]  #取原始資料，total_index的索引28為民國70年
    std_pre_fallow_money = pre_fallow_money*(100/pre_total_index)
    pre_rice_yield_per_area = 5.5
    print("假設每公頃可產生5.5公噸的米")
    pre_need = pre_population*pre_supply*10000  #需求
    pre_X = pd.DataFrame({"farmer":[pre_farmer],
                          "need":[pre_need],
                          "std_fallow_money":[std_pre_fallow_money],
                          "rice_yield_per_area":[pre_rice_yield_per_area]})
    
    print("預測中......")
    std_preX = std_model.transform(pre_X)
    pre_area = lm.predict(std_preX)
    print("預測{:d}年水稻種植面積：{:,.2f} 公頃".format(pre_year, pre_area[0]))
    state = input("請問是否要繼續預測 (Y/N)")















