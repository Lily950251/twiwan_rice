import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import pandas as pd
import sqlite3
plt.rc('font', family='Microsoft JhengHei')
plt.rc('axes', unicode_minus = False) #負號正常顯示
#%%資料載入
farmer = []
year = []
rice_area = []
conn = sqlite3.connect(r'資料庫\project.sqlite')
sql_str = '''SELECT "農業就業人口 (%)"\
FROM "農業勞動力"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    farmer.append(row[0])

sql_str = '''SELECT "年份","稻米種植面積(公頃)"\
FROM "水稻生產資料"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])

conn.close()

year = pd.Series(year)
rice_area = pd.Series(rice_area)
farmer = pd.Series(farmer)
#%%農民占比_水稻種植面積 繪圖
fig, ax1 = plt.subplots()
plt.xlabel("年份 (民國)",size = 16)
plt.xlim(42,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, rice_area,
                color = "green",
                alpha = 0.4,
                label = "水稻種植面積")
ax1.set_ylabel("水稻種植面積 (公頃)", color = "green", size = 16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot2, = ax2.plot(year,farmer,
                 color = "black",
                 linewidth = 3,
                 label = "農民占比")
ax2.set_ylabel("農民佔總就業人口的比例 (%)", size = 16, color = "black")
ax2.set_ylim(0,100)
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')

plt.legend(handles = [plot1, plot2],
           bbox_to_anchor = (1,1),  
           loc = "lower right",  #圖例的何處和錨點對齊
           ncol = 2)

plt.savefig("area_farmer.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)

#%%皮爾森相關性
data = pd.DataFrame({"rice_area":rice_area,"farmer":farmer})
cor = data.corr()

plt.figure()

sns.heatmap(cor,
            vmin = -1,
            vmax = 1,
            annot = True)
plt.savefig("farmer_ricearea_cor.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)


