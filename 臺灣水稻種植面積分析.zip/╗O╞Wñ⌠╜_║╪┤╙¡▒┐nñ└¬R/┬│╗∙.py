import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import pandas as pd
import numpy as np
import sqlite3
plt.rc('font', family='Microsoft JhengHei')
plt.rc('axes', unicode_minus = False)
#%%
year = []
rice_area = []
rice_price = []
total_index = []
cereal_index = []
conn = sqlite3.connect(r'資料庫\project.sqlite')
sql_str = '''SELECT "年份","稻米種植面積(公頃)"\
FROM "水稻生產資料"\
WHERE "年份" BETWEEN 82 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])

sql_str = '''SELECT "糧價"\
FROM "糧價"\
WHERE "年份" BETWEEN 82 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    rice_price.append(row[0])

sql_str = '''SELECT "總指數","穀類及其製品"\
FROM "消費者物價基本分類暨項目群指數"\
WHERE "年份" BETWEEN 82 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    total_index.append(row[0])
    cereal_index.append(row[1])
    
conn.close()

year = pd.Series(year)
rice_area = pd.Series(rice_area)
rice_price = pd.Series(rice_price)
total_index = pd.Series(total_index)
cereal_index = pd.Series(cereal_index)
#%%物價指數_糧價
fig, ax = plt.subplots()
ax2 = ax.twinx()
plt.xlabel("年份 (民國)",size = 16)  #不知道為什麼顯示不出來
plt.xlim(82,112)

line1, = ax.plot(year,total_index,
                 color = "black",
                 linewidth = 3,
                 label = "消費物價總指數")
line2, = ax.plot(year,cereal_index,
                 "--",
                 color = "blue",
                 linewidth = 3,
                 alpha = 0.5,
                 label = "穀物消費物價指數")
ax.set_ylabel("消費物價指數",size = 16,color = "black")
ax.tick_params(axis = 'y', labelcolor = 'black', color = 'black')

line3, = ax2.plot(year,rice_price,
                  color = "green",
                  linewidth = 3,
                  label = "糧價")
ax2.set_ylabel("糧價 (NTD)", size = 16, color = "green")
ax2.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plt.legend(handles = [line1,line2,line3],
            bbox_to_anchor = (1,1),  
            loc = "lower right",  #圖例的何處和錨點對齊
            ncol = 3)

plt.savefig("price_index",
            transparent = True,
            pad_inches = 0.5,
            dpi = 300)

#%%糧價標準化
std_price = rice_price*(100/cereal_index)

#%%糧價_面積
fig, ax1 = plt.subplots()

plt.xlabel("年份 (民國)",size = 16)
plt.xlim(82,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, rice_area,
        color = "green",
        alpha = 0.4,
        label = "水稻種植面積")
ax1.set_ylabel("水稻種植面積 (公頃)", color = "green", size = 16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot2, = ax2.plot(year,std_price,
         color = "black",
         linewidth = 3,
         label = "標準化糧價")
ax2.set_ylabel("標準化糧價", size = 16, color = "black")
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')
ax2.set_ylim(0,60)
ax2.set_yticks(np.array([0,5,10,15,20,25,30,35,40,45,50,55,60])) #將刻度拉成相等的間距 (原本的間距很怪)
plt.legend(handles = [plot1,plot2],
            bbox_to_anchor = (1,1),  
            loc = "lower right",  #圖例的何處和錨點對齊
            ncol = 2)
plt.savefig("area_price.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)

#%%皮爾森相關分析  面積-糧價
data = pd.DataFrame({"rice_area":rice_area,"std_price":std_price})
cor = data.corr()

plt.figure()

sns.heatmap(cor,
            vmin = -1,
            vmax = 1,
            annot=True)
plt.savefig("price_ricearea_cor.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)
 

