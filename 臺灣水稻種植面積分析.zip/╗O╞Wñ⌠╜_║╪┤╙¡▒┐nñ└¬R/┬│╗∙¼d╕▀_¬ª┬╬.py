#爬糧價
from selenium import webdriver
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys 
from bs4 import BeautifulSoup
import csv
#%%
url = "https://foodinformation.afa.gov.tw/Search/Login.aspx"
driver = webdriver.Chrome()
driver.implicitly_wait(5)
driver.get(url)
sleep(5)
#手動輸入驗證碼 --> 年平均 (按月份)
#%%82~113
price_list = []
year = 114
state = True
while state:    
    try:
        select = driver.find_element(By.ID,"baseContent_cph_mainContent_cph_qryYear_ddl_ddl")
        select.click()
        select.send_keys(Keys.DOWN)
        select.click()
        enter = driver.find_element(By.ID,"baseContent_cph_mainContent_cph_query_btn")
        enter.click()
        year -= 1
        sleep(3)
        bsdata = BeautifulSoup(driver.page_source,"lxml")
        table = bsdata.find("table",{"id":"baseContent_cph_mainContent_cph_main_gv"})
        price = table.find("td",{"align":"right"}).text
        price = eval(price)
        price_list.append([year,price])
        
    except:
        print(year,"載入失敗")
    if year == 82:
        state = False
        
driver.quit()
price_list.reverse()
#%%存檔
with open("糧價.csv","w",newline="") as file:
    csvwriter = csv.writer(file)
    csvwriter.writerow(["年分","糧價"])  # 寫入標題
    for i in price_list:
        csvwriter.writerow(i)  #i 

