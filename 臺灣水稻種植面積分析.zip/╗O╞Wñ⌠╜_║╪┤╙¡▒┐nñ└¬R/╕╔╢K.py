import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import pandas as pd
import sqlite3
#%%
year = []
rice_area = []
trans_money = []  #轉作雜糧
fallow_money = [] #休耕
total_index = [0]*28  #前面28年沒有資料-->補0
corn_area = []
soybean_area = []

conn = sqlite3.connect(r'資料庫\project.sqlite')
sql_str = '''SELECT "年份","稻米種植面積(公頃)"\
FROM "水稻生產資料"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    year.append(row[0])
    rice_area.append(row[1])
    
sql_str = '''SELECT "最高轉作雜糧", "休耕補貼(綠肥)"\
FROM "政策補貼"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    trans_money.append(row[0])
    fallow_money.append(row[1])
    
sql_str = '''SELECT "總指數"\
FROM "消費者物價基本分類暨項目群指數"\
WHERE "年份" BETWEEN 70 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    total_index.append(row[0])

sql_str = '''SELECT "飼料玉米", "大豆"\
FROM "雜糧種植面積_玉米大豆"\
WHERE "年份" BETWEEN 42 AND 112'''
cursor = conn.execute(sql_str)
rows = cursor.fetchall()
for row in rows:
    corn_area.append(row[0])
    soybean_area.append(row[1])

conn.close()
year = pd.Series(year)
rice_area = pd.Series(rice_area)
corn_area = pd.Series(corn_area)
soybean_area = pd.Series(soybean_area)
total_index = pd.Series(total_index)
#%% 
std_trans_money = trans_money*(100/total_index)  
std_fallow_money = fallow_money*(100/total_index)
#前面會變成nan 
std_trans_money = pd.Series(std_trans_money)
std_fallow_money = pd.Series(std_fallow_money)
std_trans_money = std_trans_money.fillna(0)
std_fallow_money = std_fallow_money.fillna(0)
#%%水稻面積_補貼金額
fig, ax1 = plt.subplots()
plt.rc('font', family='Microsoft JhengHei')
plt.xlabel("年份 (民國)",size=16)
plt.xlim(42,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, rice_area,
                color = "green",
                alpha = 0.4,
                label = "水稻種植面積")
ax1.set_ylabel("水稻種植面積 (公頃)", color = "green", size = 16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot2, = ax2.plot(year, std_trans_money,
                  color = "black",
                  linewidth = 3,
                  label = "轉作雜糧補貼")
plot3, = ax2.plot(year, std_fallow_money,
                 "--",
                 color = "blue",
                 linewidth = 3,
                 label = "休耕補貼")

ax2.set_ylabel("標準化政策補貼金額", size = 16, color = "black")
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')
ax2.yaxis.set_major_formatter(formatter)

plt.legend(handles = [plot1, plot2, plot3],
           bbox_to_anchor = (1,1),  
           loc = "lower right",  #圖例的何處和錨點對齊
           ncol = 3)

plt.savefig("money.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)
#%%雜糧面積_轉作補貼
fig, ax1 = plt.subplots()
plt.rc('font', family='Microsoft JhengHei')
plt.xlabel("年份 (民國)",size=16)
plt.xlim(42,112)
ax2 = ax1.twinx()  #建立一個共享 x 軸的第二個 y 軸的子圖
formatter = ticker.StrMethodFormatter('{x:,.0f}') #變成10,000這樣的顯示方式
plot1 = ax1.bar(year, corn_area,
                 color = "lightgreen",
                 label = "玉米")
plot2 = ax1.bar(year, soybean_area,
                 color = "darkgreen",
                 bottom = corn_area,
                 label = "大豆")
ax1.set_ylabel("玉米/大豆種植面積 (公頃)", color = "green", size = 16)
ax1.yaxis.set_major_formatter(formatter)
ax1.tick_params(axis = 'y', labelcolor = 'green', color = 'green')

plot3, = ax2.plot(year,std_trans_money,
                  color = "black",
                  linewidth = 3,
                  label = "標準化轉作雜糧補貼金額")

ax2.set_ylabel("標準化轉作雜糧補貼金額", size = 16, color = "black")
ax2.tick_params(axis = 'y', labelcolor = 'black', color = 'black')
ax2.yaxis.set_major_formatter(formatter)

plt.legend(handles = [plot1, plot2, plot3],
    bbox_to_anchor = (1,1),  
           loc = "lower right",  #圖例的何處和錨點對齊
           ncol = 3)
plt.savefig("grain_area.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)

#%%皮爾森相關性分析
data = pd.DataFrame({"rice_area":rice_area,"std_trans":std_trans_money,"std_fallow":std_fallow_money})
cor = data.corr()

#雜糧面積和補貼金額，相關性是負的，沒有預想的是正相關
# data2 = pd.DataFrame({"corn_area":corn_area,"std_trans":std_trans_money,"std_fallow":std_fallow_money})
# cor2 = data2.corr()

plt.figure()
plt.rc('axes', unicode_minus = False)
sns.heatmap(cor,
            vmin = -1,
            vmax = 1,
            annot=True)
plt.savefig("money_ricearea_cor.png",
            transparent = True,
            bbox_inches = "tight",
            pad_inches = 0.5,
            dpi = 300)


